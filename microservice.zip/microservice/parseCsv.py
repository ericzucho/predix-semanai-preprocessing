from flask import Flask
from flask_cors import CORS
import os
import csv

app = Flask(__name__)
CORS(app)

port = int(os.getenv("PORT"))


@app.route('/')
def parse_json():
    filename = "engines.csv"
    result = "{ \"engines\": ["
    with open(filename) as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            result += str(row)
            result += ","
        result = result.rstrip(',')
        result += "]}"
        return result.replace('\'', '\"')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port)
